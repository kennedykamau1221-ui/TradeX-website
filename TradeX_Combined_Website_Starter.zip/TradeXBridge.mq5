#property strict
#include <Trade/Trade.mqh>
CTrade Trade;
input string BridgeUrl="http://127.0.0.1:8787";
input string BridgeToken="CHANGE_ME";
input int PollSeconds=2;
input bool AllowLiveOrders=false;
input string LiveConfirmation="";

string Http(string method,string url,string body=""){
  char data[],result[]; string headers="",result_headers="";
  if(body!="") StringToCharArray(body,data,0,-1,CP_UTF8);
  int code=WebRequest(method,url,"x-bridge-token: "+BridgeToken+"\r\nContent-Type: application/json\r\n",5000,data,result,headers);
  if(code<200||code>=300) return "";
  return CharArrayToString(result,0,-1,CP_UTF8);
}
string JsonStr(string j,string key){string k="\""+key+"\":\"";int p=StringFind(j,k);if(p<0)return"";p+=StringLen(k);int e=StringFind(j,"\"",p);return e<0?"":StringSubstr(j,p,e-p);}
double JsonNum(string j,string key){string k="\""+key+"\":";int p=StringFind(j,k);if(p<0)return 0;p+=StringLen(k);int e=p;while(e<StringLen(j)){ushort c=StringGetCharacter(j,e);if((c>='0'&&c<='9')||c=='.'||c=='-'||c=='+')e++;else break;}return StringToDouble(StringSubstr(j,p,e-p));}
string FirstCommand(string j){int a=StringFind(j,"{\"id\"");if(a<0)return"";int b=StringFind(j,"}",a);if(b<0)return"";return StringSubstr(j,a,b-a+1);}
string BrokerSymbol(string s){if(SymbolSelect(s,true))return s;string u=s;StringReplace(u,"/","");if(SymbolSelect(u,true))return u;return s;}
void Snapshot(){
 string sym=_Symbol; double bid=SymbolInfoDouble(sym,SYMBOL_BID),ask=SymbolInfoDouble(sym,SYMBOL_ASK);
 string j="{\"account\":{\"login\":"+IntegerToString((long)AccountInfoInteger(ACCOUNT_LOGIN))+",\"balance\":"+DoubleToString(AccountInfoDouble(ACCOUNT_BALANCE),2)+",\"equity\":"+DoubleToString(AccountInfoDouble(ACCOUNT_EQUITY),2)+"},\"positions\":[";
 bool first=true; for(int i=0;i<PositionsTotal();i++){ulong t=PositionGetTicket(i);if(t==0)continue;if(!first)j+=",";first=false;string ps=PositionGetString(POSITION_SYMBOL);j+="{\"ticket\":"+IntegerToString((long)t)+",\"symbol\":\""+ps+"\",\"type\":"+IntegerToString((int)PositionGetInteger(POSITION_TYPE))+",\"volume\":"+DoubleToString(PositionGetDouble(POSITION_VOLUME),2)+",\"profit\":"+DoubleToString(PositionGetDouble(POSITION_PROFIT),2)+"}";}j+="] ,\"quotes\":{\""+sym+"\":{\"bid\":"+DoubleToString(bid,_Digits)+",\"ask\":"+DoubleToString(ask,_Digits)+"}}}";
 Http("POST",BridgeUrl+"/api/mt5/snapshot",j);
}
void Execute(string c){
 if(!AllowLiveOrders || LiveConfirmation!="TRADEX_LIVE_CONFIRM") return;
 string side=JsonStr(c,"side"), requested=JsonStr(c,"symbol"); string sym=BrokerSymbol(requested); double vol=JsonNum(c,"volume"),sl=JsonNum(c,"sl"),tp=JsonNum(c,"tp");
 if(!SymbolSelect(sym,true)||vol<=0){Http("POST",BridgeUrl+"/api/mt5/result","{\"id\":\""+JsonStr(c,"id")+"\",\"status\":\"REJECTED\",\"message\":\"Invalid symbol or volume\"}");return;}
 bool ok=false; if(side=="BUY") ok=Trade.Buy(vol,sym,0,sl,tp,"TradeX"); else if(side=="SELL") ok=Trade.Sell(vol,sym,0,sl,tp,"TradeX");
 string result="{\"id\":\""+JsonStr(c,"id")+"\",\"status\":\""+(ok?"FILLED":"REJECTED")+"\",\"symbol\":\""+sym+"\",\"side\":\""+side+"\",\"volume\":"+DoubleToString(vol,2)+",\"retcode\":"+IntegerToString((int)Trade.ResultRetcode())+",\"message\":\""+Trade.ResultRetcodeDescription()+"\"}";
 Http("POST",BridgeUrl+"/api/mt5/result",result);
}
void Poll(){string j=Http("GET",BridgeUrl+"/api/mt5/commands");if(j=="")return;string c=FirstCommand(j);if(c!="")Execute(c);}
int OnInit(){EventSetTimer(MathMax(1,PollSeconds));return INIT_SUCCEEDED;}
void OnDeinit(const int reason){EventKillTimer();}
void OnTimer(){Snapshot();Poll();}
