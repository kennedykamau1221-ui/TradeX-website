@echo off
title TradeX Pro
cd /d "%~dp0"
echo Installing/checking dependencies...
call npm install
if errorlevel 1 (
  echo.
  echo npm install failed. Make sure Node.js 18+ is installed.
  pause
  exit /b 1
)
start "" http://localhost:8787
npm start
pause
